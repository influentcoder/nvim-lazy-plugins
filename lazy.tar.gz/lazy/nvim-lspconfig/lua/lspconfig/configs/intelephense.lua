-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- This config is DEPRECATED.
-- Use the configs in `lsp/` instead (requires Nvim 0.11).
--
-- ALL configs in `lua/lspconfig/configs/` will be DELETED.
-- They exist only to support Nvim 0.10 or older.
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
local util = require 'lspconfig.util'

return {
  default_config = {
    cmd = { 'intelephense', '--stdio' },
    filetypes = { 'php' },
    root_dir = function(pattern)
      local cwd = vim.uv.cwd()
      local root = util.root_pattern('composer.json', '.git')(pattern)

      -- prefer cwd if root is a descendant
      return util.path.is_descendant(cwd, root) and cwd or root
    end,
  },
  docs = {
    description = [[
https://intelephense.com/

`intelephense` can be installed via `npm`:
```sh
npm install -g intelephense
```

```lua
-- See https://github.com/bmewburn/intelephense-docs/blob/master/installation.md#initialisation-options
init_options = {
  storagePath = …, -- Optional absolute path to storage dir. Defaults to os.tmpdir().
  globalStoragePath = …, -- Optional absolute path to a global storage dir. Defaults to os.homedir().
  licenceKey = …, -- Optional licence key or absolute path to a text file containing the licence key.
  clearCache = …, -- Optional flag to clear server state. State can also be cleared by deleting {storagePath}/intelephense
}
-- See https://github.com/bmewburn/intelephense-docs
settings = {
  intelephense = {
    files = {
      maxSize = 1000000;
    };
  };
}
```
]],
  },
}

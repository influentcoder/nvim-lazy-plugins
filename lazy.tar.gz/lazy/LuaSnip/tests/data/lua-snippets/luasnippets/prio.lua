return {
	parse("aaaa", "lua"),
}
